#include<stdio.h>

int main(){
    printf("189\n");
    printf("kothi gate ,gopi pura\n");
    printf("hapur\n");
    printf("pin-245101\n");
    return 0;
}