#include<stdio.h>

int main(){
    int a,b, sum;
    printf("Enter a\n");
    scanf("%d",&a);
    printf("Enter b\n");
    scanf("%d",&b);
    sum = a+b;
    printf("sum is %d\n",sum); 
    return 0;
}