#include<stdio.h>

int main(){
    printf("Hellow World!\n");
    printf("This is the first lab.\n");
    return 0;
}

